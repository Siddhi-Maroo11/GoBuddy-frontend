import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface SimulationStep {
  lat: number;
  lng: number;
}

@Injectable({ providedIn: 'root' })
export class DriverSimulationService {
  private interval: any = null;
  private paused: boolean = false;
  private coords: [number, number][] = [];
  private step: number = 0;
  private onCompleteCb: (() => void) | null = null;

  public isRunning: boolean = false;
  public step$ = new Subject<SimulationStep>();

  public start(coords: [number, number][], durationMs: number, onComplete: () => void): void {
    this.stop();
    if (coords.length < 2) {
      onComplete();
      return;
    }

    this.coords = coords;
    this.step = 0;
    this.paused = false;
    this.isRunning = true;

    const intervalMs = durationMs / (coords.length - 1);

    this.interval = setInterval(() => {
      if (this.paused) return;

      if (this.step >= this.coords.length) {
        this.stop();
        const last = this.coords[this.coords.length - 1];
        this.step$.next({ lat: last[1], lng: last[0] });
        onComplete();
        return;
      }

      const [lng, lat] = this.coords[this.step]; 
      this.step$.next({ lat, lng });
      this.step++;
    }, intervalMs);
  }

  public pause(): void {
    this.paused = true;
    this.isRunning = false;
  }

  public resume(): void {
    this.paused = false;
    this.isRunning = true;
  }

  public stop(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    this.isRunning = false;
    this.paused = false;
    this.coords = [];
    this.step = 0;
  }

  public get isPaused(): boolean {
    return this.paused;
  }
}
